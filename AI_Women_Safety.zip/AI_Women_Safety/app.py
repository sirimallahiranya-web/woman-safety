"""
app.py  -  AI-Based Women's Safety Alarm System (PROTOTYPE)
Run with:  streamlit run app.py

All AI features here are prototype / decision-support tools.
They can be wrong and must NOT be relied on for real personal safety.
"""
import time
from datetime import datetime

import numpy as np
import pandas as pd
import plotly.express as px
import matplotlib.pyplot as plt
import streamlit as st

import motion_detection as md
import risk_prediction as rp

try:
    import voice_detection as vd
    VOICE_OK = True
except ImportError:          # librosa not installed
    VOICE_OK = False

st.set_page_config(page_title="AI Women's Safety Alarm", page_icon="🛡️", layout="wide")

# ----------------------------------------------------------------------------
# Session state (Streamlit's memory between button clicks)
# ----------------------------------------------------------------------------
DEFAULTS = {
    "sos_status": "Safe",            # "Safe" or "ALERT ACTIVATED"
    "contact_name": "",
    "contact_phone": "",
    "countdown_seconds": 5,
    "pending": None,                 # running countdown: {"source", "message", "end"}
    "voice_result": "Not tested",
    "voice_details": None,
    "motion_result": "Not tested",
    "motion_status": "Normal",       # or "Possible Emergency Detected"
    "motion_details": None,
    "risk_level": "Not checked",
    "risk_probs": None,
    "alerts": [],
}
for key, value in DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = value


def add_alert(kind, detail):
    st.session_state.alerts.append(
        {"Time": datetime.now().strftime("%H:%M:%S"), "Type": kind, "Details": detail})


def contact_text():
    name, phone = st.session_state.contact_name, st.session_state.contact_phone
    return f"{name} ({phone})" if (name or phone) else "Not set"


# ----------------------------------------------------------------------------
# Countdown logic (used by SOS, voice and motion pages)
# ----------------------------------------------------------------------------
def start_countdown(source, message):
    st.session_state.pending = {
        "source": source, "message": message,
        "end": time.time() + st.session_state.countdown_seconds}


def cancel_countdown():
    p = st.session_state.pending
    if p:
        add_alert("Cancelled", f"{p['source']} alert cancelled by user before activation")
        if p["source"] == "MOTION":
            st.session_state.motion_status = "Alert cancelled"
    st.session_state.pending = None


def cancel_sos():
    st.session_state.sos_status = "Safe"
    add_alert("SOS", "SOS alert cancelled / user marked safe")


def finish_countdown():
    p = st.session_state.pending
    st.session_state.pending = None
    if p["source"] == "SOS":
        st.session_state.sos_status = "ALERT ACTIVATED"
        add_alert("SOS", f"SOS ACTIVATED. Simulated message sent to {contact_text()}")
    elif p["source"] == "MOTION":
        st.session_state.motion_status = "Possible Emergency Detected"
        add_alert("Motion", "Possible Emergency Detected (motion alert not cancelled)")


def countdown_banner(container):
    """Shown at the top of every page while a countdown is running."""
    p = st.session_state.pending
    if not p:
        return
    remaining = int(np.ceil(p["end"] - time.time()))
    if remaining <= 0:
        finish_countdown()
        st.rerun()
    with container:
        st.error(f"⏳ {p['message']} in **{remaining}** seconds ...")
        st.button("❌ CANCEL ALERT", key="cancel_pending", on_click=cancel_countdown, type="primary")
    time.sleep(1)
    st.rerun()


# ----------------------------------------------------------------------------
# Cached model / data loaders
# ----------------------------------------------------------------------------
@st.cache_resource
def get_risk_model():
    return rp.load_risk_model()


@st.cache_resource
def get_voice_model():
    return vd.load_voice_model()


@st.cache_data
def load_data():
    rp.load_risk_model()  # makes sure the CSV exists
    return pd.read_csv(rp.DATA_PATH)


def overall_status():
    s = st.session_state
    if s.sos_status == "ALERT ACTIVATED":
        return "error", "🚨 EMERGENCY - SOS alert is active"
    if s.motion_status == "Possible Emergency Detected" or s.voice_result == "Emergency Detected":
        return "error", "🚨 Possible emergency detected by AI features"
    if s.voice_result == "Possible Distress" or s.risk_level == "High" or \
            s.motion_result not in ("Not tested", md.NORMAL):
        return "warning", "⚠️ Caution - some indicators need attention"
    return "success", "✅ No active alerts"


# ----------------------------------------------------------------------------
# Page 1: Home / SOS
# ----------------------------------------------------------------------------
def page_home():
    st.markdown("""
        <style>
        div.stButton > button[kind="primary"] {
            height: 5.5rem; font-size: 2rem; font-weight: 800;
            background-color: #d62828; border: none; border-radius: 1rem;
        }
        </style>""", unsafe_allow_html=True)

    st.title("🛡️ AI-Based Women's Safety Alarm System")
    st.caption("Prototype / decision-support demo. Not a replacement for real emergency services. "
               "In a real emergency call your local emergency number (India: 112).")

    if st.session_state.sos_status == "ALERT ACTIVATED":
        st.error("🚨 EMERGENCY STATUS: ALERT ACTIVATED")
        st.write(f"📨 *Simulated* message to **{contact_text()}**: "
                 f"\"SOS! I need help. Alert sent at {datetime.now():%H:%M}.\"")
        if not st.session_state.contact_phone:
            st.warning("No emergency contact saved yet - add one below.")
        st.button("✅ Cancel Alert (I am safe)", on_click=cancel_sos, use_container_width=True)
    else:
        st.success("Emergency status: Safe")
        busy = st.session_state.pending is not None
        st.button("🚨 SOS", type="primary", use_container_width=True, disabled=busy,
                  on_click=start_countdown,
                  args=("SOS", "SOS alert will be ACTIVATED"))
        st.caption("Pressing SOS starts a countdown so an accidental press can be cancelled.")

    st.divider()
    left, right = st.columns(2)
    with left:
        st.subheader("⏱️ Countdown")
        st.slider("Countdown before alert activates (seconds)", 2, 15,
                  key="countdown_seconds")
    with right:
        st.subheader("👤 Emergency contact")
        with st.form("contact_form"):
            name = st.text_input("Contact name", value=st.session_state.contact_name)
            phone = st.text_input("Phone number", value=st.session_state.contact_phone)
            if st.form_submit_button("💾 Save contact"):
                st.session_state.contact_name = name.strip()
                st.session_state.contact_phone = phone.strip()
                st.success("Contact saved.")
        st.caption("This demo only *simulates* sending a message. A real app could use an SMS service.")


# ----------------------------------------------------------------------------
# Page 2: Dashboard
# ----------------------------------------------------------------------------
def page_dashboard():
    st.title("📊 Safety Dashboard")
    kind, msg = overall_status()
    getattr(st, kind)(f"**Current safety status:** {msg}")

    s = st.session_state
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("SOS status", s.sos_status)
    c2.metric("Voice detection", s.voice_result)
    c3.metric("Motion detection", s.motion_result)
    c4.metric("Current risk level", s.risk_level)

    c5, c6 = st.columns(2)
    c5.metric("Emergency contact", contact_text())
    c6.metric("Motion alert status", s.motion_status)

    st.subheader("🔔 Recent alerts")
    if s.alerts:
        df = pd.DataFrame(s.alerts[::-1]).head(10)
        st.dataframe(df, use_container_width=True, hide_index=True)
        counts = pd.DataFrame(s.alerts)["Type"].value_counts().reset_index()
        counts.columns = ["Type", "Count"]
        st.plotly_chart(px.bar(counts, x="Type", y="Count", title="Alerts by type"),
                        use_container_width=True)
    else:
        st.info("No alerts yet. Try the SOS, Voice, Motion and Crime Risk pages.")
    st.caption("All results are prototype decision-support outputs and may be wrong.")


# ----------------------------------------------------------------------------
# Page 3: Voice detection
# ----------------------------------------------------------------------------
def page_voice():
    st.title("🎙️ AI Distress Voice Detection")
    st.warning("Prototype: the model is trained on synthetic sounds and may produce "
               "**false alarms or miss real distress**. Use only as a demo.")
    if not VOICE_OK:
        st.error("The 'librosa' package is not installed. Run: pip install librosa soundfile")
        return

    source = st.radio("Audio source", ["Upload audio file", "Record audio", "Demo sample"],
                      horizontal=True)
    audio_file, demo_kind = None, None
    if source == "Upload audio file":
        audio_file = st.file_uploader("Upload a short audio clip", type=["wav", "mp3", "ogg", "flac"])
    elif source == "Record audio":
        if hasattr(st, "audio_input"):
            audio_file = st.audio_input("Record a short clip")
        else:
            st.info("Recording needs Streamlit 1.39+. Please upload a file instead.")
    else:
        demo_kind = st.selectbox("Synthetic demo clip", ["Calm voice-like tone", "Loud scream-like tone"])

    transcript = st.text_input("What was said? (optional - type it, e.g. 'help me')")
    auto = st.checkbox("Try automatic speech-to-text (WAV only, needs internet)")

    if audio_file is not None:
        st.audio(audio_file)

    if st.button("🔍 Analyze audio"):
        try:
            if demo_kind:
                kind = "normal" if demo_kind.startswith("Calm") else "distress"
                y, sr = vd.synth_clip(kind, seed=7)
            elif audio_file is not None:
                audio_file.seek(0)
                y, sr = vd.load_audio(audio_file)
                if auto:
                    audio_file.seek(0)
                    text = vd.transcribe_wav(audio_file)
                    if text:
                        transcript = f"{transcript} {text}".strip()
                        st.info(f"Transcript: {text}")
            else:
                st.warning("Please provide an audio clip first.")
                st.stop()

            res = vd.analyze_voice(y, sr, get_voice_model(), transcript)
            res["wave"] = y[::100].tolist()
            st.session_state.voice_details = res
            st.session_state.voice_result = res["label"]
            if res["label"] != vd.NORMAL_VOICE:
                add_alert("Voice", f"{res['label']} (distress score {res['distress_probability']:.0%})")
        except Exception as e:      # keep the demo friendly
            st.error(f"Could not process the audio: {e}")

    d = st.session_state.voice_details
    if d:
        st.subheader("Result")
        if d["label"] == vd.EMERGENCY:
            st.error(f"🚨 {d['label']}")
        elif d["label"] == vd.POSSIBLE:
            st.warning(f"⚠️ {d['label']}")
        else:
            st.success(f"✅ {d['label']}")

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Distress score", f"{d['distress_probability']:.0%}")
        m2.metric("Average volume (RMS)", f"{d['avg_volume']:.3f}")
        m3.metric("Peak volume", f"{d['peak_volume']:.3f}")
        m4.metric("Keywords found", ", ".join(d["keywords"]) or "None")

        fig, ax = plt.subplots(figsize=(8, 2))
        ax.plot(np.arange(len(d["wave"])) * 100 / 16000, d["wave"], linewidth=0.7)
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Amplitude")
        ax.set_title("Waveform")
        st.pyplot(fig)
        plt.close(fig)

        if d["label"] != vd.NORMAL_VOICE:
            st.warning("Possible distress was detected. Do you want to activate the SOS alert?")
            st.button("🚨 Activate SOS Alert", on_click=start_countdown,
                      args=("SOS", "SOS alert will be ACTIVATED"),
                      disabled=st.session_state.pending is not None
                      or st.session_state.sos_status == "ALERT ACTIVATED")


# ----------------------------------------------------------------------------
# Page 4: Motion detection
# ----------------------------------------------------------------------------
MOTION_KEYS = ["m_ax", "m_ay", "m_az", "m_gx", "m_gy", "m_gz", "m_idle"]
PRESETS = {
    "Normal walking":       [0.1, 0.2, 1.0, 20.0, 15.0, 10.0, 0],
    "Sudden fall":          [0.5, 0.3, 3.2, 150.0, 90.0, 60.0, 0],
    "Abnormal shaking":     [1.2, 1.0, 1.4, 320.0, 200.0, 150.0, 0],
    "Prolonged inactivity": [0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 120],
}


def apply_preset(name):
    for k, v in zip(MOTION_KEYS, PRESETS[name]):
        st.session_state[k] = v


def page_motion():
    st.title("🏃 Fall & Abnormal Motion Detection")
    st.warning("Simulation only: enter accelerometer/gyroscope values manually. "
               "Prototype rules - real sensors need calibration.")
    for k, v in zip(MOTION_KEYS, PRESETS["Normal walking"]):
        st.session_state.setdefault(k, v)

    st.write("**Quick presets**")
    cols = st.columns(len(PRESETS))
    for col, name in zip(cols, PRESETS):
        col.button(name, on_click=apply_preset, args=(name,), use_container_width=True)

    a, g = st.columns(2)
    with a:
        st.subheader("Accelerometer (g)")
        ax = st.number_input("X", step=0.1, format="%.2f", key="m_ax")
        ay = st.number_input("Y", step=0.1, format="%.2f", key="m_ay")
        az = st.number_input("Z (≈1.0 when standing still)", step=0.1, format="%.2f", key="m_az")
    with g:
        st.subheader("Gyroscope (°/s)")
        gx = st.number_input("Gx", step=10.0, format="%.1f", key="m_gx")
        gy = st.number_input("Gy", step=10.0, format="%.1f", key="m_gy")
        gz = st.number_input("Gz", step=10.0, format="%.1f", key="m_gz")
    idle = st.slider("Seconds with no movement", 0, 300, key="m_idle")

    if st.button("🔍 Analyze motion"):
        label, score, acc, gyro = md.analyze_motion(ax, ay, az, gx, gy, gz, idle)
        st.session_state.motion_result = label
        st.session_state.motion_details = {"label": label, "score": score, "acc": acc, "gyro": gyro}
        if label == md.NORMAL:
            st.session_state.motion_status = "Normal"
        else:
            add_alert("Motion", f"{label} (motion score {score})")
            start_countdown("MOTION", f"'{label}' detected - Possible Emergency will be raised")

    d = st.session_state.motion_details
    if d:
        st.subheader("Result")
        if d["label"] == md.NORMAL:
            st.success(f"✅ {d['label']}")
        elif d["label"] == md.FALL:
            st.error(f"🚨 {d['label']}")
        else:
            st.warning(f"⚠️ {d['label']}")
        m1, m2, m3 = st.columns(3)
        m1.metric("Acceleration magnitude", f"{d['acc']} g")
        m2.metric("Rotation magnitude", f"{d['gyro']} °/s")
        m3.metric("Motion score (0-100)", d["score"])
        st.progress(d["score"] / 100)

        if st.session_state.motion_status == "Possible Emergency Detected":
            st.error("🚨 Possible Emergency Detected")
            st.button("🚨 Activate SOS Alert", on_click=start_countdown,
                      args=("SOS", "SOS alert will be ACTIVATED"),
                      disabled=st.session_state.pending is not None)
        elif st.session_state.motion_status == "Alert cancelled":
            st.info("Motion alert was cancelled by the user.")


# ----------------------------------------------------------------------------
# Page 5: Crime risk prediction
# ----------------------------------------------------------------------------
def page_risk():
    st.title("📍 Crime Risk Prediction")
    st.warning("Prototype trained on a small SAMPLE (fictional) dataset. "
               "It does not detect real crimes and must not be used for real decisions.")
    model, df = get_risk_model(), load_data()

    c1, c2 = st.columns(2)
    with c1:
        loc = st.selectbox("Location", list(rp.SAMPLE_LOCATIONS) + ["Custom coordinates"])
        if loc == "Custom coordinates":
            lat = st.number_input("Latitude", value=17.40, format="%.4f")
            lon = st.number_input("Longitude", value=78.48, format="%.4f")
            area = st.selectbox("Area type", rp.AREA_TYPES)
        else:
            lat, lon, area = rp.SAMPLE_LOCATIONS[loc]
            st.caption(f"Area type: **{area}**  |  lat {lat}, lon {lon}")
    with c2:
        hour = st.slider("Time (hour of day, 0-23)", 0, 23, 22)
        day = st.selectbox("Day", rp.DAYS, index=5)

    if st.button("🔮 Predict risk level"):
        level, probs = rp.predict_risk(model, lat, lon, hour, day, area)
        st.session_state.risk_level = level
        st.session_state.risk_probs = probs
        if level == "High":
            add_alert("Risk", f"High risk predicted at {loc}, {hour:02d}:00 {day}")

    level, probs = st.session_state.risk_level, st.session_state.risk_probs
    if probs:
        st.subheader("Predicted risk level")
        if level == "High":
            st.error("🔴 HIGH RISK - avoid isolated areas, stay with others, share your location.")
        elif level == "Medium":
            st.warning("🟡 MEDIUM RISK - stay alert.")
        else:
            st.success("🟢 LOW RISK")
        prob_df = pd.DataFrame({"Risk level": list(probs), "Probability": list(probs.values())})
        st.plotly_chart(px.bar(prob_df, x="Risk level", y="Probability", range_y=[0, 1],
                               title="Model confidence"), use_container_width=True)

    st.subheader("🗺️ Sample incident / risk map")
    levels = st.multiselect("Show risk levels", ["Low", "Medium", "High"],
                            default=["Low", "Medium", "High"])
    colors = {"Low": "#2ecc71", "Medium": "#f1c40f", "High": "#e74c3c"}
    map_df = df[df["risk_level"].isin(levels)].copy()
    map_df["color"] = map_df["risk_level"].map(colors)
    map_df["size"] = 30 + map_df["incident_count"] * 15
    st.map(map_df, latitude="latitude", longitude="longitude", color="color", size="size")
    st.caption("🟢 Low   🟡 Medium   🔴 High   (bigger dot = more incidents)")
    with st.expander("View sample dataset"):
        st.dataframe(df, use_container_width=True)


# ----------------------------------------------------------------------------
# Page 6: Camera Safety Demo (optional)
# ----------------------------------------------------------------------------
def detect_people(image_bgr):
    """Count people with OpenCV's built-in HOG person detector. No faces, no identification."""
    import cv2
    h, w = image_bgr.shape[:2]
    if w > 640:
        image_bgr = cv2.resize(image_bgr, (640, int(h * 640 / w)))
    hog = cv2.HOGDescriptor()
    hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
    rects, weights = hog.detectMultiScale(image_bgr, winStride=(8, 8), padding=(8, 8), scale=1.05)
    count = 0
    for (x, y, bw, bh), wt in zip(rects, np.array(weights).flatten()):
        if wt >= 0.4:
            count += 1
            cv2.rectangle(image_bgr, (x, y), (x + bw, y + bh), (0, 200, 0), 2)
    return cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB), count


def page_camera():
    st.title("📷 Camera Safety Demo (optional)")
    st.info("Counts **people** only. No face recognition, no identification, and images are "
            "processed in memory and never saved.")
    try:
        import cv2
    except ImportError:
        st.error("OpenCV is not installed. Run: pip install opencv-python-headless")
        return

    mode = st.radio("Image source", ["Browser webcam photo", "Upload image", "Local webcam (OpenCV)"],
                    horizontal=True)
    frame = None
    if mode == "Browser webcam photo":
        shot = st.camera_input("Take a photo")
        if shot:
            frame = cv2.imdecode(np.frombuffer(shot.getvalue(), np.uint8), cv2.IMREAD_COLOR)
    elif mode == "Upload image":
        up = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png"])
        if up:
            frame = cv2.imdecode(np.frombuffer(up.getvalue(), np.uint8), cv2.IMREAD_COLOR)
    else:
        st.caption("Works only when Streamlit runs on your own computer with a webcam.")
        if st.button("Capture one frame"):
            cap = cv2.VideoCapture(0)
            ok, img = cap.read()
            cap.release()
            if ok:
                frame = img
            else:
                st.error("Could not open the webcam.")

    if frame is not None:
        annotated, count = detect_people(frame)
        st.image(annotated, caption="Detected people (green boxes)")
        if count == 0:
            st.success("No people detected.")
        elif count <= 2:
            st.info(f"{count} person(s) detected - few people around.")
        elif count <= 5:
            st.warning(f"{count} people detected - small group.")
        else:
            st.error(f"{count} people detected - crowd.")
        st.metric("People count", count)
        st.caption("Basic HOG detector: it can miss people or count false objects.")


# ----------------------------------------------------------------------------
# Navigation
# ----------------------------------------------------------------------------
PAGES = {
    "🏠 Home / SOS": page_home,
    "📊 Safety Dashboard": page_dashboard,
    "🎙️ Voice Detection": page_voice,
    "🏃 Motion Detection": page_motion,
    "📍 Crime Risk": page_risk,
    "📷 Camera Safety Demo": page_camera,
}

st.sidebar.title("🛡️ Women's Safety")
choice = st.sidebar.radio("Go to", list(PAGES))
kind, msg = overall_status()
getattr(st.sidebar, kind)(msg)
st.sidebar.caption("Prototype / decision-support only. Cannot guarantee personal safety.")

banner = st.container()      # countdown banner appears at the top of every page
PAGES[choice]()
countdown_banner(banner)

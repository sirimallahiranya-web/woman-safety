"""
generate_dataset.py
-------------------
Creates a small SAMPLE (synthetic / fictional) crime-risk dataset:  data/safety_data.csv

Columns: latitude, longitude, time, day, incident_count, area_type, risk_level

NOTE: This is NOT real crime data. It is generated with simple rules
(risk is higher at night, in transport/commercial areas, and on weekends)
so that the machine-learning model has something to learn from.
"""
import os
import numpy as np
import pandas as pd

DATA_PATH = os.path.join("data", "safety_data.csv")

# Sample hotspots: name -> (latitude, longitude, area_type). Coordinates are fictional.
HOTSPOTS = {
    "City Centre Market":  (17.4000, 78.4800, "commercial"),
    "Railway Station":     (17.4200, 78.4600, "transport"),
    "Bus Stand":           (17.3800, 78.4900, "transport"),
    "University Campus":   (17.4300, 78.5000, "educational"),
    "Green Park":          (17.3900, 78.4500, "park"),
    "Residential Colony":  (17.4100, 78.5100, "residential"),
    "Industrial Area":     (17.3700, 78.4700, "industrial"),
}

# Average incidents per time slot for each area type (base level)
BASE_RATE = {"residential": 1.5, "commercial": 3.0, "transport": 3.5,
             "educational": 2.0, "industrial": 3.0, "park": 2.5}

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def night_factor(hour):
    if hour >= 22 or hour <= 4:
        return 2.2      # late night = most risky
    if 19 <= hour <= 21:
        return 1.6      # evening
    if 5 <= hour <= 6:
        return 1.0
    return 0.7          # daytime


def level_from_rate(rate):
    """Risk level comes from the expected incident rate (the 'true' underlying risk)."""
    if rate < 2.5:
        return "Low"
    if rate < 5.5:
        return "Medium"
    return "High"


def generate(n_rows=400, seed=42):
    rng = np.random.default_rng(seed)
    names = list(HOTSPOTS.keys())
    rows = []
    for _ in range(n_rows):
        lat0, lon0, area = HOTSPOTS[names[rng.integers(len(names))]]
        lat = lat0 + rng.normal(0, 0.003)
        lon = lon0 + rng.normal(0, 0.003)
        hour = int(rng.integers(0, 24))
        minute = int(rng.integers(0, 60))
        day = DAYS[rng.integers(7)]
        weekend = 1.2 if day in ("Friday", "Saturday") else 1.0
        lam = BASE_RATE[area] * night_factor(hour) * weekend
        count = int(rng.poisson(lam))
        rows.append({
            "latitude": round(lat, 5),
            "longitude": round(lon, 5),
            "time": f"{hour:02d}:{minute:02d}",
            "day": day,
            "incident_count": count,
            "area_type": area,
            "risk_level": level_from_rate(lam),
        })
    return pd.DataFrame(rows)


if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    df = generate()
    df.to_csv(DATA_PATH, index=False)
    print(f"Saved {len(df)} rows to {DATA_PATH}")
    print(df["risk_level"].value_counts())

# 🛡️ AI-Based Women's Safety Alarm System (Prototype)

> **Disclaimer:** This is a college **prototype / decision-support** project. It cannot guarantee personal safety,
> cannot detect real crimes, and its AI detections can be wrong (false alarms and missed events).
> In a real emergency contact your local emergency services (India: **112**).

## 1. Abstract
Women's safety is a serious concern, and many safety apps depend on the user manually pressing a button.
This project presents a low-cost, software-only prototype built with Python and Streamlit that combines
several simple AI/ML features: an SOS alarm with accidental-press protection, distress voice detection
(keywords + audio features + a Random Forest), fall/abnormal-motion detection from simulated sensor values,
and a Random-Forest crime-risk predictor trained on a sample dataset. A dashboard summarizes the status of all
modules, and an optional OpenCV page counts people in an image. The system demonstrates how AI can support
early warning and quick alerting, without any special hardware.

## 2. Objectives
1. Build an easy-to-use SOS alert with a cancellable countdown and emergency-contact details.
2. Detect possible distress from audio using keywords and audio features (volume, ZCR, MFCC).
3. Detect falls / abnormal movement from accelerometer and gyroscope values.
4. Predict area risk (Low / Medium / High) from location, time and day using machine learning.
5. Show all results on one dashboard with a log of recent alerts.
6. Demonstrate privacy-friendly computer vision (person counting only, no face recognition, no stored images).

## 3. Installation
Requires Python 3.9+.
```bash
cd AI_Women_Safety
python -m venv venv
venv\Scripts\activate          # Windows      (Linux/Mac: source venv/bin/activate)
pip install -r requirements.txt
python generate_dataset.py     # creates data/safety_data.csv (already included)
python train_model.py          # trains and saves both models into data/
```

## 4. Run
```bash
streamlit run app.py
```
Then open http://localhost:8501. (If you skip `train_model.py`, the app trains the models automatically on first use.)

## 5. Project structure & file explanations
| File | Purpose |
|---|---|
| `app.py` | The Streamlit web app: 6 pages (Home/SOS, Dashboard, Voice, Motion, Crime Risk, Camera demo), countdown logic, session state. |
| `generate_dataset.py` | Creates the **synthetic** sample dataset `data/safety_data.csv` (400 rows). |
| `train_model.py` | One-click training of the risk model and the voice model. |
| `voice_detection.py` | Audio loading, feature extraction (RMS, ZCR, spectral centroid, 13 MFCC), keyword spotting, synthetic demo audio, voice classifier, final decision logic. |
| `motion_detection.py` | Rule-based fall/abnormal motion detection from accelerometer + gyroscope values. |
| `risk_prediction.py` | Prepares features, trains/loads the Random Forest, predicts Low/Medium/High risk. |
| `requirements.txt` | Python dependencies. |
| `data/safety_data.csv` | Sample dataset (`latitude, longitude, time, day, incident_count, area_type, risk_level`). Trained models (`risk_model.pkl`, `voice_model.pkl`) are also saved in `data/`. |

## 6. Machine-learning models
### Crime-risk model (Random Forest classifier)
* **Input features:** latitude, longitude, hour (from `time`), day of week (0-6), area type (encoded 0-5).
* **Output:** Low / Medium / High.
* **How it works:** a Random Forest builds many decision trees on random parts of the data; each tree votes and the
  majority vote is the prediction. It handles mixed features well and needs little tuning, so it is good for beginners.
* **Labels:** in the sample dataset the risk level comes from the expected incident rate (higher at night, in transport/commercial
  areas, and on Fridays/Saturdays). `incident_count` is the noisy observed count; it is **not** used as an input because it
  would not be known at prediction time.
* **Training:** 80/20 train-test split, 150 trees, max depth 8. On the synthetic data accuracy is high (~95%) because the data
  follows simple rules; **real data would give lower and messier results.**

### Voice distress model (Random Forest classifier)
* **Input:** 17 audio features - average volume (RMS), peak volume, zero-crossing rate, spectral centroid, 13 MFCC means.
* **Output:** probability that the clip is "distress-like" (loud, high-pitched).
* **Training data:** *synthetic* audio (calm low-pitch tones vs. loud high-pitch wobbling tones), so it demonstrates the
  pipeline but is **not reliable on real voices**. To improve: train on a real labelled dataset (e.g. RAVDESS or a scream/non-scream dataset).
* **Final decision:**
  * *Emergency Detected* = distress keyword **and** audio score ≥ 50%, **or** audio score ≥ 90%
  * *Possible Distress* = keyword **or** audio score ≥ 50%
  * *Normal Voice* = otherwise

### Motion detection (rules, not ML)
Total acceleration = √(ax²+ay²+az²) (≈1 g when still).
| Condition | Result |
|---|---|
| acc ≥ 2.5 g (impact) or acc ≤ 0.4 g (free-fall) | Sudden fall |
| acc 1.6-2.5 g or gyro ≥ 250 °/s | Abnormal/high movement |
| ≈1 g, gyro < 10 and no movement ≥ 60 s | Prolonged inactivity |
| otherwise | Normal movement |

## 7. Sample test inputs and expected outputs
**Motion page** (use the preset buttons, or type these):
| ax, ay, az (g) | gx, gy, gz (°/s) | No-movement (s) | Expected |
|---|---|---|---|
| 0.1, 0.2, 1.0 | 20, 15, 10 | 0 | Normal movement |
| 0.5, 0.3, 3.2 | 150, 90, 60 | 0 | Sudden fall → countdown → "Possible Emergency Detected" |
| 1.2, 1.0, 1.4 | 320, 200, 150 | 0 | Abnormal/high movement |
| 0, 0, 1.0 | 1, 1, 1 | 120 | Prolonged inactivity |

**Crime-risk page** (approximate results; the model may vary slightly):
| Location | Time | Day | Expected |
|---|---|---|---|
| Railway Station | 23 | Saturday | High |
| Residential Colony | 11 | Monday | Low |
| City Centre Market | 20 | Friday | Medium/High |

**Voice page:**
| Input | Expected |
|---|---|
| Demo sample "Calm voice-like tone", no text | Normal Voice |
| Demo sample "Loud scream-like tone" | Emergency Detected (audio score ≥ 90%) |
| Any calm clip + text "help me, save me" | Possible Distress (keyword only) |
| Loud clip + text "help" | Emergency Detected |

**SOS page:** press 🚨 SOS → red countdown → do nothing → status "ALERT ACTIVATED". Press ❌ Cancel during the countdown → status stays "Safe".

**Camera page:** upload a photo with 1-2 people → "few people"; photo with 6+ → "crowd". (Basic detector; results are approximate.)

## 8. System architecture / flow
```
                          ┌────────────────────────────┐
                          │   Streamlit Web Interface  │
                          │          (app.py)          │
                          └─────────────┬──────────────┘
      ┌───────────────┬────────────────┼─────────────────┬────────────────┐
      ▼               ▼                ▼                 ▼                ▼
┌───────────┐  ┌──────────────┐  ┌────────────┐  ┌───────────────┐  ┌────────────┐
│ SOS Button│  │ Voice Module │  │Motion Module│ │ Risk Module   │  │ Camera Demo│
│ + Contact │  │voice_detect. │  │motion_detect│ │risk_prediction│  │ (OpenCV)   │
└─────┬─────┘  └──────┬───────┘  └──────┬─────┘  └───────┬───────┘  └────────────┘
      │       keywords + MFCC +     acc/gyro          Random Forest
      │       Random Forest         rules             (sample CSV)
      │               │                 │                 │
      │               └───── "Distress / Abnormal detected?" ────┘
      │                              │ YES
      │                              ▼
      │                 ┌────────────────────────┐   cancel   ┌──────────────┐
      └────────────────►│ Countdown (e.g. 5 sec) │──────────► │ Alert cancel │
                        └───────────┬────────────┘            └──────────────┘
                                    │ not cancelled
                                    ▼
                        ┌────────────────────────┐
                        │ ALERT ACTIVATED        │
                        │ (simulated message to  │
                        │  emergency contact)    │
                        └───────────┬────────────┘
                                    ▼
                        ┌────────────────────────┐
                        │ Safety Dashboard +     │
                        │ Recent Alerts log      │
                        └────────────────────────┘
```

## 9. Limitations & future work
* Sample/synthetic data only; no real crime statistics. Voice model trained on synthetic audio.
* SMS/call is only simulated (a real app could use an SMS API and GPS).
* Motion values are typed manually (a real app would stream phone/wearable sensor data).
* Ideas: real datasets, real speech recognition, live GPS, mobile app, privacy and consent features.

## 10. Ethical & privacy notes
No face recognition is used and no images are stored. AI outputs are decision-support only and can produce false alarms;
they should never replace human judgement or emergency services.

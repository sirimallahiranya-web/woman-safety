"""
risk_prediction.py
------------------
Crime-risk prediction helper (prototype / decision-support only).
Uses a Random Forest model trained by train_model.py.
"""
import os
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

DATA_PATH = os.path.join("data", "safety_data.csv")
MODEL_PATH = os.path.join("data", "risk_model.pkl")

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
AREA_TYPES = ["residential", "commercial", "transport", "educational", "industrial", "park"]
FEATURES = ["latitude", "longitude", "hour", "day_num", "area_code"]

# Named sample locations for the dropdown: name -> (lat, lon, area_type)
SAMPLE_LOCATIONS = {
    "City Centre Market":  (17.4000, 78.4800, "commercial"),
    "Railway Station":     (17.4200, 78.4600, "transport"),
    "Bus Stand":           (17.3800, 78.4900, "transport"),
    "University Campus":   (17.4300, 78.5000, "educational"),
    "Green Park":          (17.3900, 78.4500, "park"),
    "Residential Colony":  (17.4100, 78.5100, "residential"),
    "Industrial Area":     (17.3700, 78.4700, "industrial"),
}


def prepare_features(df):
    """Turn the raw CSV columns into numeric model inputs."""
    out = pd.DataFrame()
    out["latitude"] = df["latitude"]
    out["longitude"] = df["longitude"]
    out["hour"] = df["time"].astype(str).str.split(":").str[0].astype(int)
    out["day_num"] = df["day"].map({d: i for i, d in enumerate(DAYS)})
    out["area_code"] = df["area_type"].map({a: i for i, a in enumerate(AREA_TYPES)})
    return out[FEATURES]


def train_risk_model(verbose=True):
    df = pd.read_csv(DATA_PATH)
    X = prepare_features(df)
    y = df["risk_level"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y)
    model = RandomForestClassifier(n_estimators=150, max_depth=8, random_state=42)
    model.fit(X_train, y_train)
    if verbose:
        pred = model.predict(X_test)
        print("Risk model accuracy:", round(accuracy_score(y_test, pred), 3))
        print(classification_report(y_test, pred, zero_division=0))
    joblib.dump(model, MODEL_PATH)
    return model


def load_risk_model():
    """Load the saved model; train it first if it does not exist yet."""
    if not os.path.exists(DATA_PATH):
        from generate_dataset import generate
        os.makedirs("data", exist_ok=True)
        generate().to_csv(DATA_PATH, index=False)
    if not os.path.exists(MODEL_PATH):
        return train_risk_model(verbose=False)
    return joblib.load(MODEL_PATH)


def predict_risk(model, lat, lon, hour, day, area_type):
    """Return (risk_level, {level: probability})."""
    row = pd.DataFrame([{
        "latitude": lat, "longitude": lon, "hour": int(hour),
        "day_num": DAYS.index(day), "area_code": AREA_TYPES.index(area_type),
    }])[FEATURES]
    level = model.predict(row)[0]
    probs = dict(zip(model.classes_, model.predict_proba(row)[0]))
    return level, probs

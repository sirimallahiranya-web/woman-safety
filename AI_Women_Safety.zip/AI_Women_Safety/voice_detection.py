"""
voice_detection.py
------------------
Prototype distress-voice detection:
  1. Keyword spotting  ("help", "save me", "emergency", ...)
  2. Audio features    (volume/RMS, zero-crossing rate, spectral centroid, MFCC)
  3. A small Random Forest that classifies audio as normal or distress-like.

IMPORTANT: The demo model is trained on SYNTHETIC audio (generated tones), so it is a
teaching prototype. It can and will produce false alarms / misses on real voices.
"""
import os
import numpy as np
import joblib
import librosa
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

SR = 16000
MODEL_PATH = os.path.join("data", "voice_model.pkl")
KEYWORDS = ["help", "save me", "emergency", "leave me", "stop", "please no", "police", "bachao"]

NORMAL_VOICE = "Normal Voice"
POSSIBLE = "Possible Distress"
EMERGENCY = "Emergency Detected"


# ---------- feature extraction ----------
def load_audio(path_or_file, duration=10):
    """Load an audio file (path or file-like object) as mono 16 kHz."""
    y, sr = librosa.load(path_or_file, sr=SR, mono=True, duration=duration)
    return y, sr


def extract_features(y, sr=SR):
    """17 numbers: mean/max volume, ZCR, spectral centroid and 13 MFCC means."""
    y = np.asarray(y, dtype=np.float32)
    rms = librosa.feature.rms(y=y)[0]
    zcr = librosa.feature.zero_crossing_rate(y)[0]
    centroid = librosa.feature.spectral_centroid(y=y, sr=sr)[0]
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
    return np.hstack([rms.mean(), rms.max(), zcr.mean(), centroid.mean(), mfcc.mean(axis=1)])


# ---------- synthetic training / demo audio ----------
def synth_clip(kind, sr=SR, duration=3.0, seed=None):
    """Make a fake 'normal' (calm, low pitch, quiet) or 'distress' (loud, high pitch) clip."""
    rng = np.random.default_rng(seed)
    t = np.linspace(0, duration, int(sr * duration), endpoint=False)
    if kind == "normal":
        f0 = rng.uniform(100, 220)
        wave = sum(np.sin(2 * np.pi * f0 * k * t) / k for k in range(1, 5))
        wave *= 1 + 0.05 * np.sin(2 * np.pi * rng.uniform(2, 5) * t)
        wave *= 0.5 * (1 + np.sin(2 * np.pi * rng.uniform(1, 3) * t))   # syllable-like pulses
        wave = wave / (np.max(np.abs(wave)) + 1e-9) * rng.uniform(0.05, 0.25)
        wave += rng.normal(0, 0.005, len(t))
    else:
        f0 = rng.uniform(700, 1500)
        freq = f0 * (1 + 0.3 * np.sin(2 * np.pi * rng.uniform(4, 8) * t))  # wobbling scream-like pitch
        phase = 2 * np.pi * np.cumsum(freq) / sr
        wave = sum(np.sin(k * phase) / k for k in range(1, 4))
        wave = wave / (np.max(np.abs(wave)) + 1e-9) * rng.uniform(0.6, 0.95)
        wave += rng.normal(0, 0.03, len(t))
    return wave.astype(np.float32), sr


def train_voice_model(n_per_class=150, verbose=True):
    X, y = [], []
    for i in range(n_per_class):
        for label, kind in ((0, "normal"), (1, "distress")):
            clip, sr = synth_clip(kind, duration=2.0, seed=i * 2 + label)
            X.append(extract_features(clip, sr))
            y.append(label)
    X, y = np.array(X), np.array(y)
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_tr, y_tr)
    if verbose:
        print("Voice model accuracy (synthetic data):", round(accuracy_score(y_te, model.predict(X_te)), 3))
    os.makedirs("data", exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    return model


def load_voice_model():
    if os.path.exists(MODEL_PATH):
        return joblib.load(MODEL_PATH)
    return train_voice_model(verbose=False)


# ---------- keyword detection ----------
def detect_keywords(text):
    """Return the list of distress keywords found in a transcript."""
    text = (text or "").lower()
    return [k for k in KEYWORDS if k in text]


def transcribe_wav(path):
    """Optional: speech-to-text using the free Google web API (needs internet, WAV files only)."""
    try:
        import speech_recognition as sr
        rec = sr.Recognizer()
        with sr.AudioFile(path) as source:
            audio = rec.record(source)
        return rec.recognize_google(audio)
    except Exception:
        return ""


# ---------- final decision ----------
def analyze_voice(y, sr, model, transcript=""):
    """
    Combine keyword + audio evidence.
      Emergency Detected : keyword AND audio looks distressed, OR audio very confidently distressed
      Possible Distress  : keyword OR audio moderately distressed
      Normal Voice       : otherwise
    """
    feats = extract_features(y, sr)
    prob = float(model.predict_proba(feats.reshape(1, -1))[0][1])
    keywords = detect_keywords(transcript)

    if (keywords and prob >= 0.5) or prob >= 0.9:
        label = EMERGENCY
    elif keywords or prob >= 0.5:
        label = POSSIBLE
    else:
        label = NORMAL_VOICE

    return {
        "label": label,
        "distress_probability": prob,
        "keywords": keywords,
        "avg_volume": float(feats[0]),
        "peak_volume": float(feats[1]),
        "zcr": float(feats[2]),
        "centroid": float(feats[3]),
    }

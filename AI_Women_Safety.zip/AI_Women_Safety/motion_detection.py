"""
motion_detection.py
-------------------
Rule-based fall / abnormal motion detection using simulated
accelerometer (in g) and gyroscope (in degrees/second) values.
Prototype only - a real phone/wearable sensor would need calibration.
"""
import math

NORMAL = "Normal movement"
FALL = "Sudden fall"
ABNORMAL = "Abnormal/high movement"
INACTIVE = "Prolonged inactivity"


def acceleration_magnitude(ax, ay, az):
    """Total acceleration = sqrt(ax^2 + ay^2 + az^2). Standing still is about 1 g."""
    return math.sqrt(ax ** 2 + ay ** 2 + az ** 2)


def gyro_magnitude(gx, gy, gz):
    return math.sqrt(gx ** 2 + gy ** 2 + gz ** 2)


def motion_score(acc_mag, gyro_mag):
    """Simple 0-100 score: how far from 'resting' (1 g, no rotation) the reading is."""
    return min(100, round(abs(acc_mag - 1.0) * 40 + gyro_mag / 8))


def analyze_motion(ax, ay, az, gx, gy, gz, inactive_seconds=0, inactivity_limit=60):
    """
    Returns (label, score, acc_mag, gyro_mag).

    Rules (thresholds are easy to explain in a presentation):
      * Sudden fall        : acc >= 2.5 g (impact)  OR  acc <= 0.4 g (free-fall)
      * Abnormal movement  : acc between 1.6 and 2.5 g  OR  gyro >= 250 deg/s
      * Prolonged inactivity: almost no motion for >= inactivity_limit seconds
      * Normal movement    : everything else
    """
    acc = acceleration_magnitude(ax, ay, az)
    gyro = gyro_magnitude(gx, gy, gz)
    score = motion_score(acc, gyro)

    if acc >= 2.5 or acc <= 0.4:
        label = FALL
    elif acc >= 1.6 or gyro >= 250:
        label = ABNORMAL
    elif inactive_seconds >= inactivity_limit and abs(acc - 1.0) < 0.1 and gyro < 10:
        label = INACTIVE
    else:
        label = NORMAL
    return label, score, round(acc, 2), round(gyro, 1)

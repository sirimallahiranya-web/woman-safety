"""
train_model.py
--------------
Run once:  python train_model.py
1. Generates the sample dataset (if missing)
2. Trains + saves the crime-risk Random Forest  -> data/risk_model.pkl
3. Trains + saves the voice distress classifier -> data/voice_model.pkl
"""
import os
from generate_dataset import generate, DATA_PATH
from risk_prediction import train_risk_model


def main():
    os.makedirs("data", exist_ok=True)
    if not os.path.exists(DATA_PATH):
        generate().to_csv(DATA_PATH, index=False)
        print("Dataset created.")

    print("\n=== Training crime-risk model ===")
    train_risk_model()

    print("\n=== Training voice distress model ===")
    try:
        from voice_detection import train_voice_model
        train_voice_model()
    except ImportError:
        print("librosa not installed - skipping voice model (pip install librosa)")
    print("\nDone. Now run:  streamlit run app.py")


if __name__ == "__main__":
    main()
